-- Inserts na tabela uf 
INSERT INTO uf VALUES (1, 'AC', 'Acre')
/
INSERT INTO uf VALUES (2, 'AL', 'Alagoas')
/
INSERT INTO uf VALUES (3, 'AM', 'Amazonas')
/
INSERT INTO uf VALUES (4, 'AP', 'Amapá')
/
INSERT INTO uf VALUES (5, 'BA', 'Bahia')
/
INSERT INTO uf VALUES (6, 'CE', 'Ceará')
/
INSERT INTO uf VALUES (7, 'DF', 'Distrito Federal')
/
INSERT INTO uf VALUES (8, 'ES', 'Espírito Santo')
/
INSERT INTO uf VALUES (9, 'GO', 'Goiás')
/
INSERT INTO uf VALUES (10, 'MA', 'Maranhão')
/
INSERT INTO uf VALUES (11, 'MG', 'Minas Gerais')
/
INSERT INTO uf VALUES (12, 'MS', 'Mato Grosso do Sul')
/
INSERT INTO uf VALUES (13, 'MT', 'Mato Grosso')
/
INSERT INTO uf VALUES (14, 'PA', 'Pará')
/
INSERT INTO uf VALUES (15, 'PB', 'Paraíba')
/
INSERT INTO uf VALUES (16, 'PE', 'Pernambuco')
/
INSERT INTO uf VALUES (17, 'PI', 'Piauí')
/
INSERT INTO uf VALUES (18, 'PR', 'Paraná')
/
INSERT INTO uf VALUES (19, 'RJ', 'Rio de Janeiro')
/
INSERT INTO uf VALUES (20, 'RN', 'Rio Grande do Norte')
/
INSERT INTO uf VALUES (21, 'RO', 'Rondônia')
/
INSERT INTO uf VALUES (22, 'RR', 'Roraima')
/
INSERT INTO uf VALUES (23, 'RS', 'Rio Grande do Sul')
/
INSERT INTO uf VALUES (24, 'SC', 'Santa Catarina')
/
INSERT INTO uf VALUES (25, 'SE', 'Sergipe')
/
INSERT INTO uf VALUES (26, 'SP', 'São Paulo')
/
INSERT INTO uf VALUES (27, 'TO', 'Tocantins')
/
commit
/
